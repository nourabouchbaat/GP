CREATE TABLE `personnels` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NOM` longtext NOT NULL,
  `PRENOM` longtext NOT NULL,
  `CIN` char(20) DEFAULT NULL,
  `TELEPHONE` longtext,
  `ADRESSE` text,
  `CNSS` longtext,
  `RIB` longtext,
  `DATE_EMBAUCHE` date DEFAULT NULL,
  `TYPE` longtext NOT NULL,
  `SALAIRE_MENSUELLE` double DEFAULT NULL,
  `TARIF_JOURNALIERS` double DEFAULT NULL,
  `CODE` longtext,
  `ID_POSTES` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
INSERT INTO personnels VALUES ('1', 'SALOUMI', 'ACHRAF', 'HA132587', '0524645128', 'MARRAKECH', '14785239', '222124578963258', '1985-08-07', 'Salarie', '11000', '0', 'TECH', '1', '1');
INSERT INTO personnels VALUES ('2', 'bouchbaat', 'noura', 'ee260968', '05522114466', 'SAFI', '88774455', '2222222222222222', '1985-08-07', 'Ouvrier', '0', '120', 'TECH', '1', '1');
INSERT INTO personnels VALUES ('3', 'ttt', 'tt', 't', 't', 't', 't', 'tt', '2015-11-30', 'Ouvrier', '0', '100', 'YY', '2', '1');
