CREATE TABLE `users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `LOGIN` text,
  `PASSWORD` text,
  `NOM` text,
  `PRENOM` text,
  `EMAIL` text,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
INSERT INTO users VALUES ('1', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'achraf', 'saloumi', 'a.mareshal@gmail.com');
