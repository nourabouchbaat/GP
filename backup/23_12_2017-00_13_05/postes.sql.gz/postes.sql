CREATE TABLE `postes` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `POSTE` longtext,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
INSERT INTO postes VALUES ('1', 'Chef Chantier');
INSERT INTO postes VALUES ('2', 'p2');
INSERT INTO postes VALUES ('3', 'p3');
INSERT INTO postes VALUES ('4', 'p4');
INSERT INTO postes VALUES ('6', 'dd');
