CREATE TABLE `chantiers` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ID_CHEF` int(11) DEFAULT NULL,
  `CODE` text,
  `ID_MARCHE` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
INSERT INTO chantiers VALUES ('1', '1', 'Route Rass ain', '1');
INSERT INTO chantiers VALUES ('3', '1', 'route youssoufia', '1');
INSERT INTO chantiers VALUES ('5', '2', 'Route chamaaia', '1');
