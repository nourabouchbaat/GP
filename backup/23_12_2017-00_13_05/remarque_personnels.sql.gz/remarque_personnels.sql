CREATE TABLE `remarque_personnels` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ID_PERSONNELS` int(11) NOT NULL,
  `REMARQUE` text NOT NULL,
  `DATE_REMARQUE` date NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
INSERT INTO remarque_personnels VALUES ('1', '1', 'test', '2017-12-19');
INSERT INTO remarque_personnels VALUES ('2', '1', 'test4', '2017-12-19');
