CREATE TABLE `caution_definitive` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DATE_CAUTION_DEFINITIVE` date DEFAULT NULL,
  `N_CAUTION` int(11) DEFAULT NULL,
  `MONTANT` double DEFAULT NULL,
  `BANQUE` text,
  `ID_MARCHE` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
INSERT INTO caution_definitive VALUES ('1', '2017-12-01', '444', '40000', 'Populaire', '1');
INSERT INTO caution_definitive VALUES ('3', '2016-12-01', '4000', '4000', 'Populaire', '1');
INSERT INTO caution_definitive VALUES ('4', '2017-12-31', '5', '5', '', '1');
INSERT INTO caution_definitive VALUES ('5', '2017-12-31', '4000', '777777', '', '1');
